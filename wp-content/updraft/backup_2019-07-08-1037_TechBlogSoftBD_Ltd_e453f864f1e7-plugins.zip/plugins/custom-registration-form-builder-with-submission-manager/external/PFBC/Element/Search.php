<?php
class Element_Search extends Element_Textbox {
	protected $_attributes = array(
		"type" => "search",
		"class" => "search-query"
	);
}
