<?php
class Element_UserPassword extends Element_Textbox {
	protected $_attributes = array("type" => "password");
}
